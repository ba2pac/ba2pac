# Instax
## Author: github.com/dhasirar
## IG: instagram.com/dhasirar
### Don't copy this code without give me the credits, 
Instax is an tool to perform multi-threaded brute force attack against Instagram, this script can bypass login limiting and it can test infinite number of passwords with a rate of +400 passwords/min using 20 threads.

## Legal disclaimer:
Usage of Instax for attacking targets without prior mutual consent is illegal. It's the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program.

## Proof:
![insta](https://user-images.githubusercontent.com/50268203/81773518-694f8800-94b6-11ea-859d-9c2362d71dd4.gif)

### Features
- Multi-thread (400 pass/min, 20 threads)
- Save/Resume sessions
- Anonymous attack through TOR
- Check valid usernames
- Default password list (best +39k 8 letters)
- Check and Install all dependencies

### Usage:
```
git clone https://github.com/dhasirar/instax.git
cd instax
chmod +x instax.sh
service tor start
bash instax.sh
```

### Install requirements (Curl, Tor, Openssl):

```
chmod +x install.sh
bash install.sh
```

### How it works?
Tool uses TOR and rotating the ip address to avoid blocking. 

### Donate!
Support the authors:
https://paypal.me/dhasirar
